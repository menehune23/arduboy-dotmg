dotMG Package Source

This is the latest source and may contain changes not yet available in the latest zip archive
